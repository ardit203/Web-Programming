package mk.ukim.finki.wp.jan2025g1.model;

public enum HistoricalPeriod {
    PREHISTORIC,
    ANCIENT,
    MEDIEVAL,
    RENAISSANCE
}