package mk.ukim.finki.wp.jan2025g2.service.impl;

public class ParkLocationServiceImpl {
}
