package mk.ukim.finki.wp.jan2025g2.repository;

public interface NationalParkRepository {
}
